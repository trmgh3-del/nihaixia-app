/* 知识库驱动的四诊规则层
 * 规则名称与 static/data/diagnosis.json 中的六经公式、脉舌速查、七步走相对应。
 * 本模块只生成学习用证据，不输出医疗诊断或处方。
 */
import { loadData } from './data.js'

const MERIDIANS = ['太阳', '阳明', '少阳', '太阴', '少阴', '厥阴']
const RULES = [
  ['太阳', 3, ['脉位=浮', '寒热=恶寒']], ['太阳', 3, ['汗=无汗', '脉形=紧']], ['太阳', 3, ['汗=有汗自汗', '寒热=恶风']],
  ['阳明', 3, ['寒热=但热不寒', '口渴=渴喜冷饮']], ['阳明', 3, ['大便=便秘', '脉形=洪']],
  ['少阳', 3, ['寒热=往来寒热', '脉形=弦']], ['少阳', 3, ['胸腹=胸胁苦满', '口渴=口苦咽干']],
  ['太阴', 3, ['大便=溏泄', '胃口=差/食少']], ['太阴', 3, ['头身=身重困倦', '舌苔=白腻']],
  ['少阴', 3, ['睡眠=但欲寐', '脉形=细']], ['少阴', 3, ['手足温度=手脚冰凉', '脉力=微']],
  ['厥阴', 3, ['口渴=消渴多饮', '手足温度=手心热脚凉']],
  ['太阳少阳合病', 2, ['寒热=恶寒', '脉形=弦']], ['少阳阳明合病', 2, ['寒热=往来寒热', '大便=便秘']],
  ['少阳太阴合病', 2, ['寒热=往来寒热', '大便=溏泄']], ['太阳少阴两感', 2, ['寒热=恶寒', '脉位=沉']],
  ['太阴少阴并病', 2, ['大便=溏泄', '脉形=细', '手足温度=手脚冰凉']]
]
const KB_QUERIES = [
  { title: '快速诊断流程图', keys: ['恶寒', '脉浮', '脉沉', '往来寒热', '但热不寒'] },
  { title: '脉诊速查', keys: ['浮缓', '浮紧', '沉迟', '沉微', '弦数', '弦缓', '微细欲绝', '结代'] },
  { title: '舌诊速查', keys: ['舌淡胖大齿痕', '舌红绛', '舌青紫', '舌红苔白', '舌淡苔白'] },
  { title: '脉舌矛盾', keys: ['脉数但舌淡', '脉沉但舌红', '脉浮但舌苔厚腻'] },
  { title: '七步走', keys: ['定表里', '分阴阳', '辨寒热', '判传变', '审体质', '选方剂'] },
  { title: '用药铁律', keys: ['有汗用麻黄', '无汗用桂枝', '少阳用汗法', '少阴用汗法'] }
]

function values(pick) { return Object.keys(pick || {}).filter(k => pick[k]).map(k => k + '=' + pick[k]) }
function matchRule(rule, vals) { return rule[2].every(x => vals.includes(x)) }

function runRules(pick, basic, rules) {
  const vals = values(pick)
  const scores = {}; const evidence = []
  MERIDIANS.forEach(m => { scores[m] = 0 })
  rules.forEach(rule => {
    const name = Array.isArray(rule) ? rule[0] : rule.name
    const points = Array.isArray(rule) ? rule[1] : rule.score
    const needs = Array.isArray(rule) ? rule[2] : rule.when
    if (!needs.every(x => vals.includes(x))) return
    const mers = MERIDIANS.filter(m => name.includes(m))
    mers.forEach(m => { scores[m] += points })
    evidence.push({ name, points, needs, source: Array.isArray(rule) ? '六经辨证诊断公式·临床速查' : (rule.sourceTitle || '六经辨证诊断公式·临床速查'), sourceId: rule.sourceId || '' })
  })
  if (basic.caseType === '慢性内伤') evidence.push({ name: '外感规则不宜直接套用', points: 0, needs: [], source: '六经辨证公式·适用边界' })
  if (basic.duration === '超过2周' || basic.duration === '反复发作') evidence.push({ name: '病程较长，建议结合内伤/杂病资料复核', points: 0, needs: [], source: '七步走辨证思维模式' })
  const matched = evidence.filter(e => e.points > 0).length
  return { scores, evidence: evidence.slice(0, 24), matchedRules: matched, ruleCount: rules.length, coverage: rules.length ? Math.round(matched / rules.length * 100) : 0 }
}

export function evaluateKnowledge(pick, basic = {}) { return runRules(pick, basic, RULES) }

export async function evaluateKnowledgeAsync(pick, basic = {}) {
  try {
    const compiled = await loadData('sizhen-rules')
    return { ...runRules(pick, basic, compiled.rules || []), modelVersion: compiled.version || 'unknown' }
  } catch (e) {
    return { ...runRules(pick, basic, RULES), modelVersion: 'fallback-local' }
  }
}

export async function findKnowledgeSources(pick) {
  try {
    const compiled = await loadData('sizhen-rules')
    const items = compiled.knowledgeItems || []
    const terms = Object.keys(pick || {}).filter(k => pick[k]).map(k => String(pick[k])).filter(x => x.length > 1)
    const scored = items.map(it => {
      const hay = it.title + ' ' + it.excerpt
      const hits = terms.filter(t => hay.includes(t))
      return { it, hits, score: hits.length * 2 + (hay.includes('诊断公式') ? 1 : 0) }
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score)
    return scored.slice(0, 8).map(({ it, hits }) => ({ id: it.id, title: it.title, source: it.group, hits }))
  } catch (e) {
    try {
      const data = await loadData('diagnosis')
      const items = (data.groups || []).flatMap(g => g.items || [])
      const text = values(pick).join(' ')
      return items.filter(it => text.includes(it.t) || String(it.b || '').split('').some(c => text.includes(c))).slice(0, 3).map(it => ({ id: it.id, title: it.t, source: '辨证知识库', hits: [] }))
    } catch (err) { return [] }
  }
}

export async function findSimilarCases(pick, meridians = []) {
  try {
    const data = await loadData('cases_table')
    const terms = Object.keys(pick || {}).filter(k => pick[k]).map(k => String(pick[k])).filter(x => x.length > 1)
    const mers = meridians || []
    const ranked = (data.rows || []).map(row => {
      const hay = [row.diag, row.bingji, row.fangji, row.result, row.guandian].join(' ')
      const hits = terms.filter(t => hay.includes(t))
      const merHits = mers.filter(m => hay.includes(m))
      return { row, score: hits.length * 2 + merHits.length, hits: hits.concat(merHits) }
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score)
    return ranked.slice(0, 3).map(({ row, hits }) => ({
      id: 'c' + row.n, date: row.date || '日期未载', title: row.diag || '未标注诊断',
      excerpt: String(row.bingji || row.result || '').replace(/[#*`]/g, '').slice(0, 160), formula: String(row.fangji || '').replace(/[#*`]/g, '').slice(0, 120), hits
    }))
  } catch (e) { return [] }
}

export { MERIDIANS }
